package com.example.doan2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MonitorFragment extends Fragment {

    TextView tvTemp, tvHumidity;
    SwitchMaterial swMode, swLight, swFan, swPump, swFeeder;

    // Khởi tạo các biến Firebase và Thư viện OkHttp
    FirebaseDatabase database;
    DatabaseReference rootRef;
    OkHttpClient client = new OkHttpClient();

    // IP của ESP32 (Hãy đổi IP này trùng với IP mạch thực tế của bạn)
    String espIp = "172.20.10.10";

    // Cờ chống lặp sự kiện bất tận khi đồng bộ UI từ Firebase về App
    private boolean isUpdatingFromFirebase = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_monitor, container, false);

        // 1. Ánh xạ các View từ Layout XML
        tvTemp = view.findViewById(R.id.tv_temperature);
        tvHumidity = view.findViewById(R.id.tv_humidity);
        swMode = view.findViewById(R.id.switch_mode);
        swLight = view.findViewById(R.id.switch_light);
        swFan = view.findViewById(R.id.switch_fan);
        swPump = view.findViewById(R.id.switch_pump);
        swFeeder = view.findViewById(R.id.switch_feeder);

        // 2. Khởi tạo đường dẫn Firebase Node gốc "SmartFarm"
        database = FirebaseDatabase.getInstance();
        rootRef = database.getReference("SmartFarm");

        // 3. LẮNG NGHE ĐỒNG BỘ DỮ LIỆU THỜI GIAN THỰC TỪ FIREBASE
        rootRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    isUpdatingFromFirebase = true;

                    // Đọc dữ liệu cảm biến
                    String nhietDo = String.valueOf(snapshot.child("nhiet_do").getValue());
                    String doAm = String.valueOf(snapshot.child("do_am").getValue());

                    if (snapshot.hasChild("nhiet_do")) {
                        tvTemp.setText(nhietDo + " °C");
                    }
                    if (snapshot.hasChild("do_am")) {
                        tvHumidity.setText(doAm + " %");
                    }

                    // Đọc trạng thái chế độ hoạt động (0: Tự động, 1: Thủ công)
                    long modeVal = 0;
                    if (snapshot.hasChild("che_do")) {
                        Long tempMode = snapshot.child("che_do").getValue(Long.class);
                        if (tempMode != null) modeVal = tempMode;
                    }

                    boolean isManual = (modeVal == 1);
                    swMode.setChecked(isManual);
                    swMode.setText(isManual ? "THỦ CÔNG" : "TỰ ĐỘNG");

                    // LOGIC KHÓA/MỞ NÚT: Nếu Tự động -> Khóa nút cứng. Nếu Thủ công -> Mở khóa bấm
                    swLight.setEnabled(isManual);
                    swFan.setEnabled(isManual);
                    swPump.setEnabled(isManual);
                    swFeeder.setEnabled(isManual);

                    // Đồng bộ trạng thái ON/OFF của các thiết bị từ Firebase lên nút gạt App
                    if (snapshot.hasChild("thiet_bi")) {
                        DataSnapshot thietBiSnapshot = snapshot.child("thiet_bi");

                        if (thietBiSnapshot.hasChild("den_suoi")) {
                            swLight.setChecked(thietBiSnapshot.child("den_suoi").getValue(Long.class) == 1);
                        }
                        if (thietBiSnapshot.hasChild("quat_gio")) {
                            swFan.setChecked(thietBiSnapshot.child("quat_gio").getValue(Long.class) == 1);
                        }
                        if (thietBiSnapshot.hasChild("may_bom")) {
                            swPump.setChecked(thietBiSnapshot.child("may_bom").getValue(Long.class) == 1);
                        }
                        if (thietBiSnapshot.hasChild("may_cho_an")) {
                            swFeeder.setChecked(thietBiSnapshot.child("may_cho_an").getValue(Long.class) == 1);
                        }
                    }

                    isUpdatingFromFirebase = false;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (getContext() != null) {
                    Toast.makeText(getContext(), "Lỗi kết nối Firebase!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 4. CÀI ĐẶT SỰ KIỆN ĐIỀU KHIỂN KHI NGƯỜI DÙNG TÁC ĐỘNG

        // Thay đổi chế độ hoạt động (Lưu thẳng lên tổng đài Firebase để mạch cập nhật theo)
        swMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isUpdatingFromFirebase) return;
            rootRef.child("che_do").setValue(isChecked ? 1 : 0);
        });

        // Gạt công tắc Đèn sưởi ấm
        swLight.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isUpdatingFromFirebase) return;
            String path = isChecked ? "/light/on" : "/light/off";
            sendHttpRequest(path, "den_suoi", isChecked ? 1 : 0);
        });

        // Gạt công tắc Quạt thông gió
        swFan.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isUpdatingFromFirebase) return;
            String path = isChecked ? "/fan/on" : "/fan/off";
            sendHttpRequest(path, "quat_gio", isChecked ? 1 : 0);
        });

        // Gạt công tắc Máy bơm nước
        swPump.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isUpdatingFromFirebase) return;
            String path = isChecked ? "/pump/on" : "/pump/off";
            sendHttpRequest(path, "may_bom", isChecked ? 1 : 0);
        });

        // Gạt công tắc Máy cho ăn tự động
        swFeeder.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isUpdatingFromFirebase) return;
            String path = isChecked ? "/feeder/on" : "/feeder/off";
            sendHttpRequest(path, "may_cho_an", isChecked ? 1 : 0);
        });

        return view;
    }

    /**
     * Hàm xử lý phát yêu cầu HTTP Request bất đồng bộ qua OkHttp tới ESP32, đồng thời cập nhật Firebase
     */
    private void sendHttpRequest(String path, String firebaseChildName, int stateValue) {
        // Cập nhật Firebase song song để đồng bộ dữ liệu tổng
        rootRef.child("thiet_bi").child(firebaseChildName).setValue(stateValue);

        // Tạo đường link URL kết nối (Ví dụ: http://172.20.10.10/pump/on)
        String url = "http://" + espIp + path;

        Request request = new Request.Builder()
                .url(url)
                .build();

        // OkHttp tự động bắn lệnh chạy ngầm (Asynchronous Call), không lo treo App chính
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                // Xử lý báo lỗi mất mạng cục bộ khi không tìm thấy thiết bị ESP32
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() ->
                            Toast.makeText(getContext(), "❌ Lỗi: Không thể gửi lệnh HTTP tới ESP32!", Toast.LENGTH_SHORT).show()
                    );
                }
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    response.close(); // Đóng kết nối an toàn giải phóng bộ nhớ RAM
                }
            }
        });
    }
}