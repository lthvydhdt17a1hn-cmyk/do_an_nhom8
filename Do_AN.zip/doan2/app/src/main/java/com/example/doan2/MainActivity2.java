package com.example.doan2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity2 extends AppCompatActivity {

    TextInputEditText etGmailRegister, etPassRegister;
    Button btnTiepTheo;
    TextView tvDangNhapNgay;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Khởi tạo Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Ánh xạ theo ID trong activity_main2.xml
        etGmailRegister = findViewById(R.id.gmail2);
        etPassRegister = findViewById(R.id.pass2);
        btnTiepTheo = findViewById(R.id.bt_tt);
        tvDangNhapNgay = findViewById(R.id.tv_dn2);

        // Quay lại màn hình Đăng nhập (ac1)
        tvDangNhapNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnTiepTheo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String gmail = etGmailRegister.getText().toString().trim();
                String pass = etPassRegister.getText().toString().trim();

                if (gmail.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(MainActivity2.this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!gmail.endsWith("@gmail.com")) {
                    etGmailRegister.setError("Gmail phải có đuôi @gmail.com");
                    return;
                }

                if (pass.length() < 6) {
                    etPassRegister.setError("Mật khẩu phải từ 6 ký tự");
                    return;
                }

                // ĐĂNG KÝ VỚI FIREBASE
                mAuth.createUserWithEmailAndPassword(gmail, pass)
                        .addOnCompleteListener(MainActivity2.this, task -> {
                            if (task.isSuccessful()) {
                                Toast.makeText(MainActivity2.this, "Đăng ký Firebase thành công!", Toast.LENGTH_SHORT).show();
                                finish(); // Quay lại màn hình đăng nhập
                            } else {
                                String error = task.getException() != null ? task.getException().getMessage() : "Lỗi không xác định";
                                Toast.makeText(MainActivity2.this, "Đăng ký thất bại: " + error, Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });
    }
}
