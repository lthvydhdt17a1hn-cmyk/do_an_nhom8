package com.example.doan2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity9 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Thiết lập nạp giao diện tiện ích lịch tiêm phòng
        setContentView(R.layout.activity_main9);

        // Code khởi tạo cho RecyclerView hoặc nút bấm thêm lịch của bạn sẽ viết tiếp ở dưới này
    }
}