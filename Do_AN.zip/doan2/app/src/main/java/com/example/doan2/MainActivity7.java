package com.example.doan2;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import java.util.Locale;

public class MainActivity7 extends AppCompatActivity {

    private LinearLayout btnAddFood, btnAddWater;

    private View rowFood1, rowFood2, rowWater1, rowWater2;

    private TextView txtTimeFood1, txtPeriodFood1, txtTimeFood2, txtPeriodFood2;
    private TextView txtTimeWater1, txtPeriodWater1, txtTimeWater2, txtPeriodWater2;

    private ImageView btnEditFood1, btnEditFood2, btnEditWater1, btnEditWater2;
    private ImageView btnDeleteFood1, btnDeleteFood2, btnDeleteWater1, btnDeleteWater2;

    private SwitchCompat switchFood1, switchFood2, switchWater1, switchWater2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        initViews();
        setupSwitches();
        setupClickListeners();
    }

    private void initViews() {
        btnAddFood = findViewById(R.id.btnAddFood);
        btnAddWater = findViewById(R.id.btnAddWater);

        rowFood1 = findViewById(R.id.rowFood1);
        rowFood2 = findViewById(R.id.rowFood2);
        rowWater1 = findViewById(R.id.rowWater1);
        rowWater2 = findViewById(R.id.rowWater2);

        txtTimeFood1 = findViewById(R.id.txtTimeFood1);
        txtPeriodFood1 = findViewById(R.id.txtPeriodFood1);
        txtTimeFood2 = findViewById(R.id.txtTimeFood2);
        txtPeriodFood2 = findViewById(R.id.txtPeriodFood2);

        txtTimeWater1 = findViewById(R.id.txtTimeWater1);
        txtPeriodWater1 = findViewById(R.id.txtPeriodWater1);
        txtTimeWater2 = findViewById(R.id.txtTimeWater2);
        txtPeriodWater2 = findViewById(R.id.txtPeriodWater2);

        btnEditFood1 = findViewById(R.id.btnEditFood1);
        btnEditFood2 = findViewById(R.id.btnEditFood2);
        btnEditWater1 = findViewById(R.id.btnEditWater1);
        btnEditWater2 = findViewById(R.id.btnEditWater2);

        btnDeleteFood1 = findViewById(R.id.btnDeleteFood1);
        btnDeleteFood2 = findViewById(R.id.btnDeleteFood2);
        btnDeleteWater1 = findViewById(R.id.btnDeleteWater1);
        btnDeleteWater2 = findViewById(R.id.btnDeleteWater2);

        switchFood1 = findViewById(R.id.switchFood1);
        switchFood2 = findViewById(R.id.switchFood2);
        switchWater1 = findViewById(R.id.switchWater1);
        switchWater2 = findViewById(R.id.switchWater2);
    }

    private void setupSwitches() {
        setupSwitch(switchFood1);
        setupSwitch(switchFood2);
        setupSwitch(switchWater1);
        setupSwitch(switchWater2);
    }

    private void setupSwitch(SwitchCompat sw) {
        if (sw == null) return;
        applySwitchColor(sw, sw.isChecked());
        sw.setOnCheckedChangeListener((buttonView, isChecked) -> applySwitchColor(sw, isChecked));
    }

    private void applySwitchColor(SwitchCompat sw, boolean isChecked) {
        if (isChecked) {
            sw.setThumbTintList(ColorStateList.valueOf(0xFF4CAF50));
            sw.setTrackTintList(ColorStateList.valueOf(0xFFC8E6C9));
        } else {
            sw.setThumbTintList(ColorStateList.valueOf(0xFFBDBDBD));
            sw.setTrackTintList(ColorStateList.valueOf(0xFFE0E0E0));
        }
    }

    private void setupClickListeners() {

        // --- CHỈNH SỬA GIỜ ---
        if (btnEditFood1 != null) btnEditFood1.setOnClickListener(v -> showTimeBottomSheet(txtTimeFood1, txtPeriodFood1));
        if (btnEditFood2 != null) btnEditFood2.setOnClickListener(v -> showTimeBottomSheet(txtTimeFood2, txtPeriodFood2));
        if (btnEditWater1 != null) btnEditWater1.setOnClickListener(v -> showTimeBottomSheet(txtTimeWater1, txtPeriodWater1));
        if (btnEditWater2 != null) btnEditWater2.setOnClickListener(v -> showTimeBottomSheet(txtTimeWater2, txtPeriodWater2));

        // --- XÓA HÀNG ---
        if (btnDeleteFood1 != null) btnDeleteFood1.setOnClickListener(v -> {
            rowFood1.setVisibility(View.GONE);
            Toast.makeText(this, "Đã xóa giờ ăn 1", Toast.LENGTH_SHORT).show();
        });
        if (btnDeleteFood2 != null) btnDeleteFood2.setOnClickListener(v -> {
            rowFood2.setVisibility(View.GONE);
            Toast.makeText(this, "Đã xóa giờ ăn 2", Toast.LENGTH_SHORT).show();
        });
        if (btnDeleteWater1 != null) btnDeleteWater1.setOnClickListener(v -> {
            rowWater1.setVisibility(View.GONE);
            Toast.makeText(this, "Đã xóa giờ uống nước 1", Toast.LENGTH_SHORT).show();
        });
        if (btnDeleteWater2 != null) btnDeleteWater2.setOnClickListener(v -> {
            rowWater2.setVisibility(View.GONE);
            Toast.makeText(this, "Đã xóa giờ uống nước 2", Toast.LENGTH_SHORT).show();
        });

        // --- THÊM GIỜ ---
        if (btnAddFood != null) {
            btnAddFood.setOnClickListener(v -> {
                if (rowFood1.getVisibility() == View.GONE) {
                    rowFood1.setVisibility(View.VISIBLE);
                    showTimeBottomSheet(txtTimeFood1, txtPeriodFood1);
                } else if (rowFood2.getVisibility() == View.GONE) {
                    rowFood2.setVisibility(View.VISIBLE);
                    showTimeBottomSheet(txtTimeFood2, txtPeriodFood2);
                } else {
                    Toast.makeText(this, "Chỉ cài đặt tối đa 2 mốc giờ ăn!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (btnAddWater != null) {
            btnAddWater.setOnClickListener(v -> {
                if (rowWater1.getVisibility() == View.GONE) {
                    rowWater1.setVisibility(View.VISIBLE);
                    showTimeBottomSheet(txtTimeWater1, txtPeriodWater1);
                } else if (rowWater2.getVisibility() == View.GONE) {
                    rowWater2.setVisibility(View.VISIBLE);
                    showTimeBottomSheet(txtTimeWater2, txtPeriodWater2);
                } else {
                    Toast.makeText(this, "Chỉ cài đặt tối đa 2 mốc giờ uống nước!", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void showTimeBottomSheet(final TextView txtTimeTarget, final TextView txtPeriodTarget) {
        if (txtTimeTarget == null || txtPeriodTarget == null) return;

        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View sheetView = LayoutInflater.from(this).inflate(R.layout.activity_main8, null);
        bottomSheetDialog.setContentView(sheetView);

        ImageView btnCancelSheet = sheetView.findViewById(R.id.btnCancelSheet);
        TextView btnConfirmSheet = sheetView.findViewById(R.id.btnConfirmSheet);
        TimePicker sheetTimePicker = sheetView.findViewById(R.id.sheetTimePicker);

        if (sheetTimePicker == null || btnConfirmSheet == null || btnCancelSheet == null) {
            Toast.makeText(this, "Lỗi ID trong activity_main8.xml!", Toast.LENGTH_SHORT).show();
            return;
        }

        sheetTimePicker.setIs24HourView(true);

        // Áp dụng màu ban đầu
        sheetTimePicker.post(() -> setTimePickerTextColor(sheetTimePicker, 0xFF000000));

        // Áp dụng lại màu mỗi khi cuộn giờ
        sheetTimePicker.setOnTimeChangedListener((view, hourOfDay, minute) ->
                sheetTimePicker.post(() -> setTimePickerTextColor(sheetTimePicker, 0xFF000000))
        );

        btnCancelSheet.setOnClickListener(v -> bottomSheetDialog.dismiss());

        btnConfirmSheet.setOnClickListener(v -> {
            int hour = sheetTimePicker.getHour();
            int minute = sheetTimePicker.getMinute();

            String formattedTime = String.format(Locale.getDefault(), "%02d:%02d", hour, minute);
            String period = (hour < 12) ? "Sáng" : (hour < 18 ? "Chiều" : "Tối");

            txtTimeTarget.setText(formattedTime);
            txtPeriodTarget.setText(period);

            bottomSheetDialog.dismiss();
            Toast.makeText(this, "Đã cập nhật: " + formattedTime, Toast.LENGTH_SHORT).show();
        });

        bottomSheetDialog.show();
    }

    private void setTimePickerTextColor(TimePicker timePicker, int color) {
        try {
            int idHour = Resources.getSystem().getIdentifier("hour", "id", "android");
            int idMinute = Resources.getSystem().getIdentifier("minute", "id", "android");
            int idAmPm = Resources.getSystem().getIdentifier("amPm", "id", "android");

            NumberPicker hourPicker = timePicker.findViewById(idHour);
            NumberPicker minutePicker = timePicker.findViewById(idMinute);
            NumberPicker amPmPicker = timePicker.findViewById(idAmPm);

            setNumberPickerTextColor(hourPicker, color);
            setNumberPickerTextColor(minutePicker, color);
            setNumberPickerTextColor(amPmPicker, color);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setNumberPickerTextColor(NumberPicker picker, int color) {
        if (picker == null) return;
        try {
            java.lang.reflect.Field field = NumberPicker.class.getDeclaredField("mSelectorWheelPaint");
            field.setAccessible(true);
            ((android.graphics.Paint) field.get(picker)).setColor(color);
            picker.invalidate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int i = 0; i < picker.getChildCount(); i++) {
            if (picker.getChildAt(i) instanceof android.widget.EditText) {
                ((android.widget.EditText) picker.getChildAt(i)).setTextColor(color);
            }
        }
    }
}