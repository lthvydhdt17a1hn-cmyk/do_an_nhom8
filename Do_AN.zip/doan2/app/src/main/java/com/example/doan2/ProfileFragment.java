package com.example.doan2;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileFragment extends Fragment {

    TextView tvUserEmail;
    EditText edtMaxTemp;
    Button btnSaveSetting, btnLogout;

    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference farmRef;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // 1. Khởi tạo Firebase
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        farmRef = database.getReference("SmartFarm");

        // 2. Ánh xạ các View từ XML
        tvUserEmail = view.findViewById(R.id.tv_user_email);
        edtMaxTemp = view.findViewById(R.id.edt_max_temp_setting);
        btnSaveSetting = view.findViewById(R.id.btn_save_setting);
        btnLogout = view.findViewById(R.id.btn_logout);

        // 3. Hiển thị Email người dùng hiện tại (Dùng phương thức Java chuẩn .setText)
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            tvUserEmail.setText(user.getEmail());
        }

        // 4. Đọc ngưỡng nhiệt độ hiện tại đang lưu trên Firebase để điền sẵn vào ô nhập
        farmRef.child("nguong_nhiet").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String nguongNhiet = String.valueOf(snapshot.getValue());
                    edtMaxTemp.setText(nguongNhiet);
                } else {
                    edtMaxTemp.setText("35.0"); // Giá trị mặc định nếu trên Firebase chưa có
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

        // 5. Xử lý sự kiện lưu cấu hình ngưỡng nhiệt độ lên Firebase
        btnSaveSetting.setOnClickListener(v -> {
            String maxTempStr = edtMaxTemp.getText().toString().trim();
            if (!maxTempStr.isEmpty()) {
                farmRef.child("nguong_nhiet").setValue(maxTempStr)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(getContext(), "Đã cập nhật ngưỡng nhiệt độ mới!", Toast.LENGTH_SHORT).show();
                        });
            } else {
                Toast.makeText(getContext(), "Vui lòng không để trống số độ!", Toast.LENGTH_SHORT).show();
            }
        });

        // 6. Xử lý Đăng xuất hệ thống
        btnLogout.setOnClickListener(v -> {
            mAuth.signOut();
            Toast.makeText(getContext(), "Đã đăng xuất tài khoản!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(getActivity(), MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);

            if (getActivity() != null) {
                getActivity().finish();
            }
        });

        return view;
    }
}