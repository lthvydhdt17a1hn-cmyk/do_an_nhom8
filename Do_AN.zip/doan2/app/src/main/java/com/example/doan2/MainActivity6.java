package com.example.doan2;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity6 extends AppCompatActivity {

    LinearLayout btnCamTieuThu;

    private boolean isAutoWater = false;
    private boolean isAutoFood = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        btnCamTieuThu = findViewById(R.id.cardFood);
        if (btnCamTieuThu != null) {
            btnCamTieuThu.setOnClickListener(v -> showStatusDialog());
        }
    }

    private void showStatusDialog() {
        final Dialog dialog = new Dialog(MainActivity6.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.activity_main6);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        // --- Ánh xạ ---
        ProgressBar pbWater = dialog.findViewById(R.id.pbWaterLevel);
        ProgressBar pbFood = dialog.findViewById(R.id.pbFoodLevel);

        LinearLayout btnAutoWater = dialog.findViewById(R.id.btnAutoWater);
        LinearLayout btnAutoFood = dialog.findViewById(R.id.btnAutoFood);
        LinearLayout btnDrinkSetting = dialog.findViewById(R.id.btnDrinkSetting);
        LinearLayout btnEatSetting = dialog.findViewById(R.id.btnEatSetting);

        TextView tvAutoWaterText = dialog.findViewById(R.id.tvAutoWaterText);
        TextView tvAutoFoodText = dialog.findViewById(R.id.tvAutoFoodText);

        // Tìm TextView bên trong btnDrinkSetting và btnEatSetting
        TextView tvDrinkSettingText = (TextView) btnDrinkSetting.getChildAt(0);
        TextView tvEatSettingText = (TextView) btnEatSetting.getChildAt(0);

        // Tạo TextView thông báo inline cho nước (đặt sau layout nút trong khối nước)
        // Dùng tag để tìm lại view thông báo — ở đây ta tạo động và thêm vào parent
        // Lấy parent LinearLayout của khối nước (cha của btnAutoWater/btnDrinkSetting)
        LinearLayout waterButtonRow = (LinearLayout) btnAutoWater.getParent();
        LinearLayout waterBlock = (LinearLayout) waterButtonRow.getParent();

        LinearLayout foodButtonRow = (LinearLayout) btnAutoFood.getParent();
        LinearLayout foodBlock = (LinearLayout) foodButtonRow.getParent();

        // Tạo TextView thông báo cho nước
        TextView tvWaterNotice = new TextView(this);
        tvWaterNotice.setText("🔄 Chế độ tự động uống đang được kích hoạt");
        tvWaterNotice.setTextColor(Color.parseColor("#1565C0"));
        tvWaterNotice.setTextSize(13f);
        tvWaterNotice.setPadding(8, 12, 8, 0);
        tvWaterNotice.setVisibility(View.GONE);
        waterBlock.addView(tvWaterNotice);

        // Tạo TextView thông báo cho cám
        TextView tvFoodNotice = new TextView(this);
        tvFoodNotice.setText("🔄 Chế độ tự động ăn đang được kích hoạt");
        tvFoodNotice.setTextColor(Color.parseColor("#1565C0"));
        tvFoodNotice.setTextSize(13f);
        tvFoodNotice.setPadding(8, 12, 8, 0);
        tvFoodNotice.setVisibility(View.GONE);
        foodBlock.addView(tvFoodNotice);

        // Thiết lập progress
        if (pbWater != null) pbWater.setProgress(78);
        if (pbFood != null) pbFood.setProgress(65);

        // Khôi phục trạng thái khi mở lại dialog
        applyAutoWaterState(btnAutoWater, tvAutoWaterText, btnDrinkSetting, tvDrinkSettingText, tvWaterNotice, isAutoWater);
        applyAutoFoodState(btnAutoFood, tvAutoFoodText, btnEatSetting, tvEatSettingText, tvFoodNotice, isAutoFood);

        // ===== NƯỚC: Nút Tự động =====
        if (btnAutoWater != null) {
            btnAutoWater.setOnClickListener(v -> {
                isAutoWater = true;
                applyAutoWaterState(btnAutoWater, tvAutoWaterText, btnDrinkSetting, tvDrinkSettingText, tvWaterNotice, true);
            });
        }

        // ===== NƯỚC: Nút Tùy chỉnh =====
        if (btnDrinkSetting != null) {
            btnDrinkSetting.setOnClickListener(v -> {
                if (isAutoWater) {
                    // Chỉ tắt chế độ tự động, không chuyển màn hình
                    isAutoWater = false;
                    applyAutoWaterState(btnAutoWater, tvAutoWaterText, btnDrinkSetting, tvDrinkSettingText, tvWaterNotice, false);
                } else {
                    dialog.dismiss();
                    startActivity(new Intent(MainActivity6.this, MainActivity7.class));
                }
            });
        }

        // ===== CÁM: Nút Tự động =====
        if (btnAutoFood != null) {
            btnAutoFood.setOnClickListener(v -> {
                isAutoFood = true;
                applyAutoFoodState(btnAutoFood, tvAutoFoodText, btnEatSetting, tvEatSettingText, tvFoodNotice, true);
            });
        }

        // ===== CÁM: Nút Tùy chỉnh =====
        if (btnEatSetting != null) {
            btnEatSetting.setOnClickListener(v -> {
                if (isAutoFood) {
                    isAutoFood = false;
                    applyAutoFoodState(btnAutoFood, tvAutoFoodText, btnEatSetting, tvEatSettingText, tvFoodNotice, false);
                } else {
                    dialog.dismiss();
                    startActivity(new Intent(MainActivity6.this, MainActivity7.class));
                }
            });
        }

        dialog.show();
    }

    /**
     * Áp dụng trạng thái tự động cho khối NƯỚC.
     * Bật  → btnAutoWater nền xanh nhạt (#E3F2FD), btnDrinkSetting xám, hiện thông báo
     * Tắt  → btnAutoWater mặc định (bg_button_outline), btnDrinkSetting bình thường, ẩn thông báo
     */
    private void applyAutoWaterState(LinearLayout btnAuto, TextView tvAuto,
                                     LinearLayout btnSetting, TextView tvSetting,
                                     TextView tvNotice, boolean isOn) {
        if (isOn) {
            // Nút tự động → xanh nhạt
            btnAuto.setBackgroundResource(R.drawable.bg_button_green_light);
            if (tvAuto != null) tvAuto.setTextColor(Color.parseColor("#1565C0"));

            // Nút tùy chỉnh → xám
            setButtonGray(btnSetting, tvSetting);

            // Hiện thông báo
            if (tvNotice != null) tvNotice.setVisibility(View.VISIBLE);
        } else {
            // Nút tự động → xám
            btnAuto.setBackgroundResource(R.drawable.bg_button_outline);
            if (tvAuto != null) tvAuto.setTextColor(Color.parseColor("#757575"));

            // Nút tùy chỉnh → bình thường
            setButtonNormal(btnSetting, tvSetting);

            // Ẩn thông báo
            if (tvNotice != null) tvNotice.setVisibility(View.GONE);
        }
    }

    /**
     * Áp dụng trạng thái tự động cho khối CÁM.
     */
    private void applyAutoFoodState(LinearLayout btnAuto, TextView tvAuto,
                                    LinearLayout btnSetting, TextView tvSetting,
                                    TextView tvNotice, boolean isOn) {
        if (isOn) {
            btnAuto.setBackgroundResource(R.drawable.bg_button_green_light);
            if (tvAuto != null) tvAuto.setTextColor(Color.parseColor("#1565C0"));

            setButtonGray(btnSetting, tvSetting);

            if (tvNotice != null) tvNotice.setVisibility(View.VISIBLE);
        } else {
            btnAuto.setBackgroundResource(R.drawable.bg_button_outline);
            if (tvAuto != null) tvAuto.setTextColor(Color.parseColor("#757575"));

            setButtonNormal(btnSetting, tvSetting);

            if (tvNotice != null) tvNotice.setVisibility(View.GONE);
        }
    }

    /** Đặt nút về trạng thái xám (khung + chữ) */
    private void setButtonGray(LinearLayout btn, TextView tv) {
        if (btn == null) return;
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(50f);
        gd.setColor(Color.parseColor("#F5F5F5"));
        gd.setStroke(2, Color.parseColor("#BDBDBD"));
        btn.setBackground(gd);
        if (tv != null) tv.setTextColor(Color.parseColor("#BDBDBD"));
    }

    /** Đặt nút về trạng thái bình thường (dùng drawable gốc) */
    private void setButtonNormal(LinearLayout btn, TextView tv) {
        if (btn == null) return;
        btn.setBackgroundResource(R.drawable.bg_button_outline);
        if (tv != null) tv.setTextColor(Color.parseColor("#000000"));
    }
}