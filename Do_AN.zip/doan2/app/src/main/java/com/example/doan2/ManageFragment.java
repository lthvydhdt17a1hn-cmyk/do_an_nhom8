package com.example.doan2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ManageFragment extends Fragment {

    // Khai báo các TextView hiển thị số liệu
    TextView tvBirds, tvFeed, tvVaccineDate;
    Button btnCompleteVaccine;

    // Kết nối Firebase
    FirebaseDatabase database;
    DatabaseReference farmRef;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_manage, container, false);

        // 1. Ánh xạ View từ layout XML chính xác
        tvBirds = view.findViewById(R.id.tv_total_birds);
        tvFeed = view.findViewById(R.id.tv_feed_consumption);
        tvVaccineDate = view.findViewById(R.id.tv_manage_vaccine_date);
        btnCompleteVaccine = view.findViewById(R.id.btn_complete_vaccine);

        // 2. Khởi tạo Firebase đường dẫn SmartFarm
        database = FirebaseDatabase.getInstance();
        farmRef = database.getReference("SmartFarm");

        // 3. Lắng nghe dữ liệu chăn nuôi thời gian thực từ Cloud
        farmRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {

                    // Đọc và hiển thị Tổng Đàn
                    if (snapshot.hasChild("tong_dan")) {
                        String tongDan = String.valueOf(snapshot.child("tong_dan").getValue());
                        tvBirds.setText(tongDan + " con");
                    }

                    // Đọc và hiển thị Cám Tiêu Thụ
                    if (snapshot.hasChild("cam_tieu_thu")) {
                        String camTieuThu = String.valueOf(snapshot.child("cam_tieu_thu").getValue());
                        tvFeed.setText(camTieuThu + " kg");
                    }

                    // Đọc và hiển thị Lịch Tiêm Phòng Động
                    if (snapshot.hasChild("lich_tiem")) {
                        String lichTiem = String.valueOf(snapshot.child("lich_tiem").getValue());
                        tvVaccineDate.setText("📅 Lịch: " + lichTiem);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Lỗi tải dữ liệu quản lý: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        // 4. Xử lý nút bấm báo cáo hoàn thành
        btnCompleteVaccine.setOnClickListener(v -> {
            // Khi bấm xong, ta xóa lịch tiêm cũ trên Firebase hoặc cập nhật trạng thái mới
            farmRef.child("lich_tiem").setValue("Đã hoàn thành hết lịch tiêm!")
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(getContext(), "Đã cập nhật trạng thái lên hệ thống!", Toast.LENGTH_SHORT).show();
                        btnCompleteVaccine.setEnabled(false);
                        btnCompleteVaccine.setText("Đã hoàn thành");
                    });
        });

        return view;
    }
}