package com.example.doan2;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// Thêm các thư viện kết nối Firebase bắt buộc
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity4 extends AppCompatActivity {

    // 1. Khai báo các thành phần giao diện
    private Switch switchAuto, switchFan;

    // 2. Khai báo các đường dẫn kết nối đến Firebase
    private DatabaseReference autoRef;
    private DatabaseReference quatRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main5);

        // Khấu trừ khoảng trống hệ thống (Giữ nguyên mặc định của bạn)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 3. Ánh xạ các Switch từ file giao diện XML (Khớp chính xác với bản vẽ blueprint)
        switchAuto = findViewById(R.id.switchAuto);
        switchFan = findViewById(R.id.switchFan);

        // 4. Khởi tạo kết nối Firebase tới đúng nhánh của hệ thống Trang Trại Xanh
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        autoRef = database.getReference("SmartFarm/ThongGio/CheDoAuto");
        quatRef = database.getReference("SmartFarm/ThongGio/TrangThaiQuat");

        // ==========================================
        // LUỒNG ĐỒNG BỘ 1: CHẾ ĐỘ TỰ ĐỘNG (CheDoAuto)
        // ==========================================

        // Lắng nghe dữ liệu thay đổi từ Firebase để cập nhật lên App
        autoRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Integer value = snapshot.getValue(Integer.class);
                    if (value != null) {
                        switchAuto.setChecked(value == 1);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(MainActivity4.this, "Lỗi đọc dữ liệu Tự động!", Toast.LENGTH_SHORT).show();
            }
        });

        // Đẩy dữ liệu từ App lên Firebase khi người dùng gạt nút
        switchAuto.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Nếu bật gạt ghi 1, ngược lại ghi 0
                autoRef.setValue(isChecked ? 1 : 0);
            }
        });


        // ==========================================
        // LUỒNG ĐỒNG BỘ 2: QUẠT THÔNG GIÓ (TrangThaiQuat)
        // ==========================================

        // Lắng nghe dữ liệu thay đổi từ Firebase để cập nhật lên App
        quatRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Integer value = snapshot.getValue(Integer.class);
                    if (value != null) {
                        switchFan.setChecked(value == 1);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(MainActivity4.this, "Lỗi đọc dữ liệu Quạt!", Toast.LENGTH_SHORT).show();
            }
        });

        // Đẩy dữ liệu từ App lên Firebase khi người dùng gạt nút
        switchFan.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Nếu bật gạt ghi 1, ngược lại ghi 0
                quatRef.setValue(isChecked ? 1 : 0);
            }
        });
    }
}