package com.example.doan2;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Giao diện nền của Activity 5
        setContentView(R.layout.activity_main5);

        // Gọi hàm hiển thị Dialog điều khiển
        showLightControlDialog();
    }

    private void showLightControlDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        // Nạp layout giao diện Dialog mới đã được tinh chỉnh cấu trúc cha
        dialog.setContentView(R.layout.activity_main8);

        // XỬ LÝ XÓA 4 GÓC XÁM TRIỆT ĐỂ BẰNG CÁCH THIẾT LẬP LẠI THUỘC TÍNH WINDOW
        if (dialog.getWindow() != null) {
            Window window = dialog.getWindow();

            // 1. Làm trong suốt hoàn toàn khung bao quanh của hệ thống
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            // 2. Kích hoạt tính năng làm mờ nền phía sau thay cho lớp màu cứng trong XML
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

            // Đặt độ mờ nền tương đương với màu #80000000 (0.5f nghĩa là mờ 50%)
            window.setDimAmount(0.5f);

            // 3. Đặt kích thước Dialog tự ôm sát theo đúng kích thước thiết kế XML bên trên
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(window.getAttributes());
            lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            window.setAttributes(lp);
        }

        // Ánh xạ các nút gạt (Switch)
        SwitchCompat swAuto = dialog.findViewById(R.id.switchAutoLight);
        SwitchCompat swLight = dialog.findViewById(R.id.switchLight);
        final View layoutAuto = dialog.findViewById(R.id.layoutAutoLight);
        final View layoutLight = dialog.findViewById(R.id.layoutLightControl);

        // Xử lý khi bật/tắt chế độ Tự động (Cảm biến)
        swAuto.setOnCheckedChangeListener((btn, isChecked) -> {
            if (isChecked) {
                layoutAuto.getBackground().setColorFilter(Color.parseColor("#CCFBF1"), android.graphics.PorterDuff.Mode.SRC_IN);
                swLight.setEnabled(false); // Khóa nút gạt tay
                layoutLight.setAlpha(0.5f); // Làm mờ nút gạt tay
            } else {
                layoutAuto.getBackground().clearColorFilter();
                swLight.setEnabled(true);
                layoutLight.setAlpha(1.0f);
            }
        });

        // Xử lý khi bật/tắt đèn bằng tay
        swLight.setOnCheckedChangeListener((btn, isChecked) -> {
            if (isChecked) {
                layoutLight.getBackground().setColorFilter(Color.parseColor("#CCFBF1"), android.graphics.PorterDuff.Mode.SRC_IN);
            } else {
                layoutLight.getBackground().clearColorFilter();
            }
        });

        // Nút đóng (X)
        dialog.findViewById(R.id.btn_close_light).setOnClickListener(v -> {
            dialog.dismiss();
            finish(); // Đóng Activity 5 để quay về Activity trước đó
        });

        // Không cho phép tắt dialog khi click ra ngoài vùng trắng
        dialog.setCanceledOnTouchOutside(false);

        dialog.show();
    }
}