package com.example.doan2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    TextInputEditText etGmail, etPassword;
    Button btnDangNhap;
    TextView tvDangKy;
    CheckBox cbRemember;
    SharedPreferences sharedPreferences;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Khởi tạo Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        etGmail = findViewById(R.id.gmail);
        etPassword = findViewById(R.id.pass);
        btnDangNhap = findViewById(R.id.bt_dn);
        tvDangKy = findViewById(R.id.tvDangKy);
        cbRemember = findViewById(R.id.cb_remember);

        sharedPreferences = getSharedPreferences("dataLogin", MODE_PRIVATE);

        // Tự động điền dữ liệu nếu đã lưu trước đó
        if (sharedPreferences.contains("gmail")) {
            etGmail.setText(sharedPreferences.getString("gmail", ""));
            etPassword.setText(sharedPreferences.getString("pass", ""));
            cbRemember.setChecked(sharedPreferences.getBoolean("checked", false));
        }

        // Chuyển sang màn hình Đăng ký
        tvDangKy.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            startActivity(intent);
        });

        // Xử lý Đăng nhập cua VY
        /*
        btnDangNhap.setOnClickListener(v -> {
            String email = etGmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đủ thông tin!", Toast.LENGTH_SHORT).show();
            } else {
                // ĐĂNG NHẬP VỚI FIREBASE
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(this, task -> {
                            if (task.isSuccessful()) {
                                // Xử lý Ghi nhớ thông tin
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                if (cbRemember != null && cbRemember.isChecked()) {
                                    editor.putString("gmail", email);
                                    editor.putString("pass", password);
                                    editor.putBoolean("checked", true);
                                } else {
                                    editor.clear();
                                }
                                editor.apply();

                                Toast.makeText(this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                                startActivity(intent);
                                finish();
                            } else {
                                String error = task.getException() != null ? task.getException().getMessage() : "Lỗi xác thực";
                                Toast.makeText(this, "Đăng nhập thất bại: " + error, Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });
    */
        // thich mau lam
        btnDangNhap.setOnClickListener(v -> {
            String email = etGmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đủ thông tin!", Toast.LENGTH_SHORT).show();
            } else {
                // ĐĂNG NHẬP VỚI FIREBASE
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(this, task -> {
                            if (task.isSuccessful()) {
                                // Xử lý Ghi nhớ thông tin
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                if (cbRemember != null && cbRemember.isChecked()) {
                                    editor.putString("gmail", email);
                                    editor.putString("pass", password);
                                    editor.putBoolean("checked", true);
                                } else {
                                    editor.clear();
                                }
                                editor.apply();

                                Toast.makeText(this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();

                                // ==========================================================
                                // ĐÃ CẬP NHẬT: Chuyển thẳng đến Dashboard (Thanh điều hướng)
                                // ==========================================================
                                Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                                startActivity(intent);
                                finish();
                                // ==========================================================

                            } else {
                                String error = task.getException() != null ? task.getException().getMessage() : "Lỗi xác thực";
                                Toast.makeText(this, "Đăng nhập thất bại: " + error, Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });
    }
}
