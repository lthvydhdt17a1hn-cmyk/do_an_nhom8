package com.example.doan2;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class DashboardActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Đặt Fragment mặc định khi vừa mở màn hình là HomeFragment (Tổng quan)
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new HomeFragment())
                .commit();

        // Xử lý sự kiện khi bấm vào các Tab trên thanh điều hướng
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;

                int id = item.getItemId();
                if (id == R.id.nav_home) {
                    selectedFragment = new HomeFragment();
                } else if (id == R.id.nav_monitor) {
                    // Kích hoạt trang Giám sát (Nhiệt độ, Độ ẩm, Thiết bị)
                    selectedFragment = new MonitorFragment();
                } else if (id == R.id.nav_manage) {
                    // Kích hoạt trang Quản Lý (Gia cầm, Tiêm phòng, Cám ăn)
                    selectedFragment = new ManageFragment();
                } else if (id == R.id.nav_profile) {
                    // Kích hoạt trang Cá nhân & Cài đặt
                    selectedFragment = new ProfileFragment();
                }

                // Thực hiện tráo đổi fragment
                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, selectedFragment)
                            .commit();
                    return true;
                }
                return false;
            }
        });
    }

    /**
     * HÀM BỔ SUNG: Cho phép các Fragment con (như HomeFragment)
     * có thể ra lệnh ép Dashboard chuyển Tab từ xa.
     * * @param tabIndex 1: Giám sát, 2: Quản lý đàn, 3: Lịch trình/Cám
     */
    public void selectTab(int tabIndex) {
        if (bottomNavigationView != null) {
            switch (tabIndex) {
                case 1: // Khi nhấn vào ô Nhiệt độ -> Chuyển sang Tab Giám sát
                    bottomNavigationView.setSelectedItemId(R.id.nav_monitor);
                    break;
                case 2: // Khi nhấn vào ô Tổng đàn -> Chuyển sang Tab Quản lý
                    bottomNavigationView.setSelectedItemId(R.id.nav_manage);
                    break;
                case 3: // Khi nhấn vào ô Cám hoặc Lịch tiêm -> Chuyển sang Tab Quản lý (Hoặc Tab tương ứng của bạn)
                    bottomNavigationView.setSelectedItemId(R.id.nav_manage);
                    break;
            }
        }
    }
}