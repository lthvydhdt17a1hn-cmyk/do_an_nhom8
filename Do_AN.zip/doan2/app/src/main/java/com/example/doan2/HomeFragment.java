package com.example.doan2;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;

public class HomeFragment extends Fragment {

    TextView tvHomeTemp, tvHomeBirds, tvHomeFeed, tvHomeVaccine, tvHomeDateTime;
    MaterialCardView cardTemp, cardBirds, cardFeed, cardVaccine;
    Button btnToday, btnMonth, btnYear;

    // Khai báo 3 biểu đồ riêng biệt
    LineChart chartTemp, chartBirds, chartFeed;

    FirebaseDatabase database;
    DatabaseReference farmRef, rootRef;
    Handler timeHandler = new Handler();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 1. Ánh xạ View
        tvHomeTemp = view.findViewById(R.id.tv_home_temperature);
        tvHomeBirds = view.findViewById(R.id.tv_home_total_birds);
        tvHomeFeed = view.findViewById(R.id.tv_home_feed_consumption);
        tvHomeVaccine = view.findViewById(R.id.tv_home_vaccine_schedule);
        tvHomeDateTime = view.findViewById(R.id.tv_home_date_time);

        chartTemp = view.findViewById(R.id.home_temp_chart);
        chartBirds = view.findViewById(R.id.home_birds_chart);
        chartFeed = view.findViewById(R.id.home_feed_chart);

        cardTemp = view.findViewById(R.id.card_home_temp);
        cardBirds = view.findViewById(R.id.card_home_birds);
        cardFeed = view.findViewById(R.id.card_home_feed);
        cardVaccine = view.findViewById(R.id.card_home_vaccine);

        btnToday = view.findViewById(R.id.btn_filter_today);
        btnMonth = view.findViewById(R.id.btn_filter_month);
        btnYear = view.findViewById(R.id.btn_filter_year);

        // Cấu hình định dạng cho cả 3 trục đồ thị
        setupChartStyle(chartTemp);
        setupChartStyle(chartBirds);
        setupChartStyle(chartFeed);

        startClockUpdate();

        // 2. Firebase Setup
        database = FirebaseDatabase.getInstance("https://smartfarmesp32-58a90-default-rtdb.asia-southeast1.firebasedatabase.app/");
        farmRef = database.getReference("SmartFarmESP32");
        rootRef = database.getReference("SmartFarmESP32");

        loadFarmOverview();
        loadAllChartsData("today"); // Mặc định hiển thị ngày hiện tại

        // 3. Sự kiện chuyển Tab từ thẻ card tổng quan
        cardTemp.setOnClickListener(v -> switchDashboardTab(1));
        cardBirds.setOnClickListener(v -> switchDashboardTab(2));
        cardFeed.setOnClickListener(v -> switchDashboardTab(2));
        cardVaccine.setOnClickListener(v -> switchDashboardTab(2));

        // 4. Lọc dữ liệu đồng bộ
        btnToday.setOnClickListener(v -> { highlightButton(btnToday); loadAllChartsData("today"); });
        btnMonth.setOnClickListener(v -> { highlightButton(btnMonth); loadAllChartsData("month"); });
        btnYear.setOnClickListener(v -> { highlightButton(btnYear); loadAllChartsData("year"); });

        return view;
    }

    private void switchDashboardTab(int tabIndex) {
        if (getActivity() instanceof DashboardActivity) {
            DashboardActivity activity = (DashboardActivity) getActivity();
            activity.selectTab(tabIndex);
        }
    }

    private void loadFarmOverview() {
        farmRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    if (snapshot.hasChild("nhiet_do")) tvHomeTemp.setText(snapshot.child("nhiet_do").getValue() + " °C");
                    if (snapshot.hasChild("tong_dan")) tvHomeBirds.setText(snapshot.child("tong_dan").getValue() + " con");
                    if (snapshot.hasChild("cam_tieu_thu")) tvHomeFeed.setText(snapshot.child("cam_tieu_thu").getValue() + " kg");
                    if (snapshot.hasChild("lich_tiem")) tvHomeVaccine.setText(String.valueOf(snapshot.child("lich_tiem").getValue()));
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void loadAllChartsData(String type) {
        // 1. Chuẩn hóa ngày/tháng/năm từ hệ thống để khớp hoàn toàn với cấu trúc Firebase
        Calendar calendar = Calendar.getInstance();
        String currentYear = String.valueOf(calendar.get(Calendar.YEAR)); // "2026"

        int month = calendar.get(Calendar.MONTH) + 1;
        String currentMonth = (month < 10) ? "0" + month : String.valueOf(month); // Luôn có 2 chữ số (VD: "05")

        int day = calendar.get(Calendar.DAY_OF_MONTH);
        String currentDay = (day < 10) ? "0" + day : String.valueOf(day); // Luôn có 2 chữ số (VD: "29")

        DatabaseReference tempRef, birdRef, feedRef;

        if (type.equals("today")) {
            tempRef = rootRef.child("nhiet_do_history").child(currentYear).child(currentMonth).child(currentDay);
            birdRef = rootRef.child("tong_dan_history").child(currentYear).child(currentMonth).child(currentDay);
            feedRef = rootRef.child("cam_history").child(currentYear).child(currentMonth).child(currentDay);
        } else if (type.equals("month")) {
            tempRef = rootRef.child("nhiet_do_history").child(currentYear).child(currentMonth);
            birdRef = rootRef.child("tong_dan_history").child(currentYear).child(currentMonth);
            feedRef = rootRef.child("cam_history").child(currentYear).child(currentMonth);
        } else {
            tempRef = rootRef.child("nhiet_do_history").child(currentYear);
            birdRef = rootRef.child("tong_dan_history").child(currentYear);
            feedRef = rootRef.child("cam_history").child(currentYear);
        }

        // =================================================================
        // CHART 1: BIỂU ĐỒ NHIỆT ĐỘ
        // =================================================================
        tempRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<Entry> tempEntries = new ArrayList<>();
                ArrayList<String> xLabels = new ArrayList<>();

                if (!snapshot.exists()) {
                    updateSingleChart(chartTemp, tempEntries, xLabels, "Nhiệt độ (°C)", "#0288D1");
                    return;
                }

                try {
                    int index = 0;
                    if (type.equals("today")) {
                        for (DataSnapshot timeSnap : snapshot.getChildren()) {
                            String label = timeSnap.child("time").getValue(String.class);
                            xLabels.add(label != null ? label : timeSnap.getKey());

                            if (timeSnap.hasChild("value")) {
                                Object rawVal = timeSnap.child("value").getValue();
                                if (rawVal != null) {
                                    tempEntries.add(new Entry(index, Float.parseFloat(rawVal.toString())));
                                    index++;
                                }
                            }
                        }
                    } else if (type.equals("month")) {
                        for (DataSnapshot daySnap : snapshot.getChildren()) {
                            String dayKey = daySnap.getKey();
                            xLabels.add(dayKey + "/" + currentMonth);

                            float totalDayTemp = 0;
                            int count = 0;
                            for (DataSnapshot timeSnap : daySnap.getChildren()) {
                                if (timeSnap.hasChild("value")) {
                                    Object rawVal = timeSnap.child("value").getValue();
                                    if (rawVal != null) {
                                        totalDayTemp += Float.parseFloat(rawVal.toString());
                                        count++;
                                    }
                                }
                            }
                            if (count > 0) {
                                tempEntries.add(new Entry(index, Math.round((totalDayTemp / count) * 10f) / 10f));
                                index++;
                            }
                        }
                    } else {
                        for (DataSnapshot monthSnap : snapshot.getChildren()) {
                            String monthKey = monthSnap.getKey();
                            xLabels.add("T" + monthKey);

                            float totalMonthTemp = 0;
                            int count = 0;
                            for (DataSnapshot daySnap : monthSnap.getChildren()) {
                                for (DataSnapshot timeSnap : daySnap.getChildren()) {
                                    if (timeSnap.hasChild("value")) {
                                        Object rawVal = timeSnap.child("value").getValue();
                                        if (rawVal != null) {
                                            totalMonthTemp += Float.parseFloat(rawVal.toString());
                                            count++;
                                        }
                                    }
                                }
                            }
                            if (count > 0) {
                                tempEntries.add(new Entry(index, Math.round((totalMonthTemp / count) * 10f) / 10f));
                                index++;
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                updateSingleChart(chartTemp, tempEntries, xLabels, "Nhiệt độ (°C)", "#0288D1");
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });

        // =================================================================
        // CHART 2: BIỂU ĐỒ TỔNG ĐÀN
        // =================================================================
        birdRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<Entry> birdEntries = new ArrayList<>();
                ArrayList<String> xLabels = new ArrayList<>();

                if (!snapshot.exists()) {
                    updateSingleChart(chartBirds, birdEntries, xLabels, "Số lượng còn lại (Con)", "#2E7D32");
                    return;
                }

                try {
                    int index = 0;
                    if (type.equals("today")) {
                        if (snapshot.hasChild("value")) {
                            Object rawVal = snapshot.child("value").getValue();
                            if (rawVal != null) {
                                float val = Float.parseFloat(rawVal.toString());
                                xLabels.add("Đầu ngày");
                                birdEntries.add(new Entry(0, val));
                                xLabels.add("Hiện tại");
                                birdEntries.add(new Entry(1, val));
                            }
                        }
                    } else if (type.equals("month")) {
                        for (DataSnapshot daySnap : snapshot.getChildren()) {
                            xLabels.add(daySnap.getKey() + "/" + currentMonth);
                            if (daySnap.hasChild("value")) {
                                Object rawVal = daySnap.child("value").getValue();
                                if (rawVal != null) {
                                    birdEntries.add(new Entry(index, Float.parseFloat(rawVal.toString())));
                                    index++;
                                }
                            }
                        }
                    } else {
                        for (DataSnapshot monthSnap : snapshot.getChildren()) {
                            xLabels.add("T" + monthSnap.getKey());
                            float lastValue = 0;
                            for (DataSnapshot daySnap : monthSnap.getChildren()) {
                                if (daySnap.hasChild("value")) {
                                    Object rawVal = daySnap.child("value").getValue();
                                    if (rawVal != null) {
                                        lastValue = Float.parseFloat(rawVal.toString());
                                    }
                                }
                            }
                            birdEntries.add(new Entry(index, lastValue));
                            index++;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                updateSingleChart(chartBirds, birdEntries, xLabels, "Số lượng còn lại (Con)", "#2E7D32");
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });

        // =================================================================
        // CHART 3: BIỂU ĐỒ LƯỢNG CÁM TIEU THỤ
        // =================================================================
        feedRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<Entry> feedEntries = new ArrayList<>();
                ArrayList<String> xLabels = new ArrayList<>();

                if (!snapshot.exists()) {
                    updateSingleChart(chartFeed, feedEntries, xLabels, "Khối lượng cám (Kg)", "#E65100");
                    return;
                }

                try {
                    int index = 0;
                    if (type.equals("today")) {
                        for (DataSnapshot timeSnap : snapshot.getChildren()) {
                            String label = timeSnap.child("time").getValue(String.class);
                            xLabels.add(label != null ? label : timeSnap.getKey());

                            if (timeSnap.hasChild("value")) {
                                Object rawVal = timeSnap.child("value").getValue();
                                if (rawVal != null) {
                                    feedEntries.add(new Entry(index, Float.parseFloat(rawVal.toString())));
                                    index++;
                                }
                            }
                        }
                    } else if (type.equals("month")) {
                        for (DataSnapshot daySnap : snapshot.getChildren()) {
                            xLabels.add(daySnap.getKey() + "/" + currentMonth);
                            float dailyTotal = 0;
                            for (DataSnapshot timeSnap : daySnap.getChildren()) {
                                if (timeSnap.hasChild("value")) {
                                    Object rawVal = timeSnap.child("value").getValue();
                                    if (rawVal != null) {
                                        dailyTotal += Float.parseFloat(rawVal.toString());
                                    }
                                }
                            }
                            feedEntries.add(new Entry(index, dailyTotal));
                            index++;
                        }
                    } else {
                        for (DataSnapshot monthSnap : snapshot.getChildren()) {
                            xLabels.add("T" + monthSnap.getKey());
                            float monthlyTotal = 0;
                            for (DataSnapshot daySnap : monthSnap.getChildren()) {
                                for (DataSnapshot timeSnap : daySnap.getChildren()) {
                                    if (timeSnap.hasChild("value")) {
                                        Object rawVal = timeSnap.child("value").getValue();
                                        if (rawVal != null) {
                                            monthlyTotal += Float.parseFloat(rawVal.toString());
                                        }
                                    }
                                }
                            }
                            feedEntries.add(new Entry(index, monthlyTotal));
                            index++;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                updateSingleChart(chartFeed, feedEntries, xLabels, "Khối lượng cám (Kg)", "#E65100");
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void updateSingleChart(LineChart chart, ArrayList<Entry> entries, ArrayList<String> labels, String title, String colorHex) {
        if (!entries.isEmpty()) {
            LineDataSet dataSet = new LineDataSet(entries, title);
            dataSet.setColor(Color.parseColor(colorHex));
            dataSet.setCircleColor(Color.parseColor(colorHex));
            dataSet.setLineWidth(2.5f);
            dataSet.setDrawValues(true);
            dataSet.setValueTextSize(8f);
            dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER); // Giúp đường nối uốn cong mượt mà

            chart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
            // Tự động căn chỉnh nhãn trục X không bị tràn dữ liệu
            chart.getXAxis().setLabelCount(Math.min(labels.size(), 5), true);

            LineData data = new LineData(dataSet);
            chart.setData(data);
            chart.invalidate(); // Làm mới lại biểu đồ
        } else {
            chart.clear();
        }
    }

    private void setupChartStyle(LineChart chart) {
        chart.getDescription().setEnabled(false);
        chart.setTouchEnabled(true);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setPinchZoom(true);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f); // Giữ khoảng cách đều nhau cho trục tọa độ
        xAxis.setTextColor(Color.parseColor("#78909C"));

        chart.getAxisLeft().setTextColor(Color.parseColor("#78909C"));
        chart.getAxisRight().setEnabled(false);
    }

    private void clearAllCharts(String msg) {
        chartTemp.clear(); chartTemp.setNoDataText(msg);
        chartBirds.clear(); chartBirds.setNoDataText(msg);
        chartFeed.clear(); chartFeed.setNoDataText(msg);
    }

    private void highlightButton(Button activeBtn) {
        btnToday.setTextColor(Color.parseColor("#78909C"));
        btnMonth.setTextColor(Color.parseColor("#78909C"));
        btnYear.setTextColor(Color.parseColor("#78909C"));
        activeBtn.setTextColor(Color.parseColor("#0288D1"));
    }

    private void startClockUpdate() {
        timeHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss\ndd/MM/yyyy", Locale.getDefault());
                if (tvHomeDateTime != null) tvHomeDateTime.setText(sdf.format(new Date()));
                timeHandler.postDelayed(this, 1000);
            }
        }, 0);
    }
}