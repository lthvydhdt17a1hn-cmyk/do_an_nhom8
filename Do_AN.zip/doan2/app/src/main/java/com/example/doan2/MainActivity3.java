package com.example.doan2;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

// Import thư viện Firebase Realtime Database
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity3 extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "SmartFarmPrefs";

    // Bảng màu đồng bộ cho giao diện
    private final String COLOR_BLUE_ON = "#E3F2FD";   // Xanh dương nhạt cho Tự động
    private final String COLOR_YELLOW_ON = "#FFF9C4"; // Vàng nhạt cho Bóng đèn
    private final String COLOR_OFF = "#F8FAFC";       // Màu mặc định khi tắt

    // Khai báo biến tham chiếu Firebase toàn cục để dùng chung
    private DatabaseReference farmRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // Khởi tạo kết nối tới node gốc "SmartFarm" trên Firebase
        farmRef = FirebaseDatabase.getInstance().getReference("SmartFarm");

        // 1. Mở Dialog Thông gió khi bấm vào card Nhiệt độ
        View cardNhietDo = findViewById(R.id.cardNhietDo);
        if (cardNhietDo != null) {
            cardNhietDo.setOnClickListener(v -> showFanDialog());
        }

        // 2. Mở Dialog Chiếu sáng khi bấm vào card Bật/Tắt
        View cardBongDen = findViewById(R.id.cardBongDen);
        if (cardBongDen != null) {
            cardBongDen.setOnClickListener(v -> showLightDialog());
        }

        // 3. Mở Dialog Cám & Nước khi bấm vào ô Cám tiêu thụ
        View cardFood = findViewById(R.id.cardFood);
        if (cardFood != null) {
            cardFood.setOnClickListener(v -> showFoodWaterDialog());
        }

        // 4. CHUYỂN MÀN HÌNH: Bấm vào ô Lịch tiêm phòng chuyển ngay sang MainActivity9
        View cardLichTiem = findViewById(R.id.cardLichTiem);
        if (cardLichTiem != null) {
            cardLichTiem.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity3.this, MainActivity9.class);
                startActivity(intent);
            });
        }
    }

    // --- DIALOG THÔNG GIÓ (ĐÃ TÍCH HỢP FIREBASE ĐIỀU KHIỂN QUẠT) ---
    private void showFanDialog() {
        final Dialog dialog = new Dialog(this);
        setupDialog(dialog, R.layout.activity_main4);

        SwitchCompat swAuto = dialog.findViewById(R.id.switchAuto);
        SwitchCompat swFan = dialog.findViewById(R.id.switchFan);
        SeekBar sbSpeed = dialog.findViewById(R.id.seekBarSpeed);
        TextView tvPercent = dialog.findViewById(R.id.tvSpeedPercent);
        final View layoutAuto = dialog.findViewById(R.id.layoutAuto);
        final View layoutFanAndSpeed = dialog.findViewById(R.id.layoutFanAndSpeed);

        // Tạo đường dẫn nhánh riêng cho hệ thống Thông gió: SmartFarm/ThongGio
        DatabaseReference fanRef = farmRef.child("ThongGio");

        boolean isAuto = sharedPreferences.getBoolean("auto_fan", false);
        boolean isFanOn = sharedPreferences.getBoolean("fan_on", false);
        int savedSpeed = sharedPreferences.getInt("fan_speed", 0);

        swAuto.setChecked(isAuto);
        swFan.setChecked(isFanOn);
        sbSpeed.setProgress(savedSpeed);
        tvPercent.setText(savedSpeed + "%");

        if (isAuto) {
            layoutAuto.getBackground().setTint(Color.parseColor(COLOR_BLUE_ON));
            swFan.setEnabled(false);
            layoutFanAndSpeed.setAlpha(0.5f);
        } else if (isFanOn) {
            layoutFanAndSpeed.getBackground().setTint(Color.parseColor(COLOR_BLUE_ON));
        }

        // Sự kiện nút gạt Tự động
        swAuto.setOnCheckedChangeListener((btn, isChecked) -> {
            sharedPreferences.edit().putBoolean("auto_fan", isChecked).apply();
            layoutAuto.getBackground().setTint(Color.parseColor(isChecked ? COLOR_BLUE_ON : COLOR_OFF));

            // GỬI LÊN FIREBASE: 1 là bật tự động, 0 là tắt tự động
            fanRef.child("CheDoAuto").setValue(isChecked ? 1 : 0);

            if (isChecked) {
                swFan.setChecked(false);
                swFan.setEnabled(false);
                layoutFanAndSpeed.setAlpha(0.5f);
                layoutFanAndSpeed.getBackground().setTint(Color.parseColor(COLOR_OFF));

                // Khi bật tự động thì tắt lệnh chạy quạt thủ công
                fanRef.child("TrangThaiQuat").setValue(0);
            } else {
                swFan.setEnabled(true);
                layoutFanAndSpeed.setAlpha(1.0f);
            }
        });

        // Sự kiện nút gạt Quạt thủ công
        swFan.setOnCheckedChangeListener((btn, isChecked) -> {
            sharedPreferences.edit().putBoolean("fan_on", isChecked).apply();
            layoutFanAndSpeed.getBackground().setTint(Color.parseColor(isChecked ? COLOR_BLUE_ON : COLOR_OFF));

            // GỬI LÊN FIREBASE: 1 là Bật quạt, 0 là Tắt quạt
            fanRef.child("TrangThaiQuat").setValue(isChecked ? 1 : 0);

            if (isChecked) {
                swAuto.setChecked(false);
                fanRef.child("CheDoAuto").setValue(0);
            }
        });

        // Sự kiện thanh kéo Tốc độ quạt
        sbSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean f) {
                tvPercent.setText(p + "%");
                sharedPreferences.edit().putInt("fan_speed", p).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                // Khi người dùng thả tay ra, tiến hành gửi giá trị tốc độ (0 -> 100) lên Firebase
                int progress = sb.getProgress();
                fanRef.child("TocDoQuat").setValue(progress);
            }
        });

        dialog.findViewById(R.id.btn_close).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    // --- DIALOG CHIẾU SÁNG (GIỮ NGUYÊN HOẠT ĐỘNG) ---
    private void showLightDialog() {
        final Dialog dialog = new Dialog(this);
        setupDialog(dialog, R.layout.activity_main5);

        SwitchCompat swAuto = dialog.findViewById(R.id.switchAutoLight);
        SwitchCompat swLight = dialog.findViewById(R.id.switchLight);
        final View layoutAuto = dialog.findViewById(R.id.layoutAutoLight);
        final View layoutLight = dialog.findViewById(R.id.layoutLightControl);

        boolean isAuto = sharedPreferences.getBoolean("light_auto", false);
        boolean isLightOn = sharedPreferences.getBoolean("light_on", false);

        swAuto.setChecked(isAuto);
        swLight.setChecked(isLightOn);

        if (isAuto) {
            layoutAuto.getBackground().setTint(Color.parseColor(COLOR_BLUE_ON));
            swLight.setEnabled(false);
            layoutLight.setAlpha(0.5f);
        } else if (isLightOn) {
            layoutLight.getBackground().setTint(Color.parseColor(COLOR_YELLOW_ON));
        }

        swAuto.setOnCheckedChangeListener((btn, isChecked) -> {
            sharedPreferences.edit().putBoolean("light_auto", isChecked).apply();
            layoutAuto.getBackground().setTint(Color.parseColor(isChecked ? COLOR_BLUE_ON : COLOR_OFF));
            if (isChecked) {
                swLight.setChecked(false);
                swLight.setEnabled(false);
                layoutLight.setAlpha(0.5f);
                layoutLight.getBackground().setTint(Color.parseColor(COLOR_OFF));
            } else {
                swLight.setEnabled(true);
                layoutLight.setAlpha(1.0f);
            }
        });

        swLight.setOnCheckedChangeListener((btn, isChecked) -> {
            sharedPreferences.edit().putBoolean("light_on", isChecked).apply();
            layoutLight.getBackground().setTint(Color.parseColor(isChecked ? COLOR_YELLOW_ON : COLOR_OFF));
            if (isChecked) swAuto.setChecked(false);
        });

        dialog.findViewById(R.id.btn_close_light).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    // --- DIALOG ĂN UỐNG ---
    private void showFoodWaterDialog() {
        final Dialog dialog = new Dialog(this);
        setupDialog(dialog, R.layout.activity_main6);

        ProgressBar pbWater = dialog.findViewById(R.id.pbWaterLevel);
        ProgressBar pbFood = dialog.findViewById(R.id.pbFoodLevel);

        if (pbWater != null) pbWater.setProgress(78);
        if (pbFood != null) pbFood.setProgress(65);

        LinearLayout btnDrinkNow = dialog.findViewById(R.id.btnAutoWater);
        LinearLayout btnDrinkSetting = dialog.findViewById(R.id.btnDrinkSetting);
        LinearLayout btnEatNow = dialog.findViewById(R.id.btnAutoWater);
        LinearLayout btnEatSetting = dialog.findViewById(R.id.btnEatSetting);

        if (btnDrinkNow != null) {
            btnDrinkNow.setOnClickListener(v -> {
                Toast.makeText(MainActivity3.this, "Đã cho uống!", Toast.LENGTH_SHORT).show();
            });
        }

        if (btnDrinkSetting != null) {
            btnDrinkSetting.setOnClickListener(v -> {
                dialog.dismiss();
                Intent intent = new Intent(MainActivity3.this, MainActivity7.class);
                startActivity(intent);
            });
        }

        if (btnEatNow != null) {
            btnEatNow.setOnClickListener(v -> {
                Toast.makeText(MainActivity3.this, "Đã cho ăn!", Toast.LENGTH_SHORT).show();
            });
        }

        if (btnEatSetting != null) {
            btnEatSetting.setOnClickListener(v -> {
                dialog.dismiss();
                Intent intent = new Intent(MainActivity3.this, MainActivity7.class);
                startActivity(intent);
            });
        }

        dialog.show();
    }

    // --- HÀM THIẾT LẬP DIALOG CHUẨN MẪU BO TRÒN ---
    private void setupDialog(Dialog dialog, int layoutId) {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(layoutId);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog_rounded);
            View decorView = dialog.getWindow().getDecorView();
            decorView.setClipToOutline(true);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setAttributes(lp);
        }
    }
}